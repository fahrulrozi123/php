/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","fr",{button:"Insérer un extrait de code",codeContents:"Code",emptySnippetError:"Un extrait de code ne peut pas être vide.",language:"Langue",title:"Extrait de code",pathName:"extrait de code"});